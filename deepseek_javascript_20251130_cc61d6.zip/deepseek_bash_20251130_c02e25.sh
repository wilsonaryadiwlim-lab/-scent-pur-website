# Buat folder project
mkdir scent-pur-website
cd scent-pur-website

# File structure
index.html
about.html
products.html
contact.html
css/
  style.css
images/
  product-images/
js/
  script.js